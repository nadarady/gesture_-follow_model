# Pointer — hand-guided bot

Upload a video of a hand pointing in different directions. The app detects
21 hand landmarks live in the browser (MediaPipe Hands), overlays the
skeleton on the video, and walks a small robot in the direction the index
finger is pointing.

**Everything runs client-side.** No server, no Python, no API keys, no
backend. The hand-tracking model runs via WebAssembly/WebGL in the browser,
loaded from Google's CDN.

## Switched to the legacy @mediapipe/hands library

This was the biggest change made to this project, not a tweak. After
looking at how real hand-tracking projects are actually built (including a
clinical tool for analyzing pre-recorded hand videos), nearly all of them
use the older **`@mediapipe/hands`** library — not the newer
`@mediapipe/tasks-vision` this app started with.

The reason this matters: the older library exposes a real
**`modelComplexity`** setting — `0` for the fast/lite model, `1` for the
slower/accurate full model. That's the lite-vs-full accuracy lever that
flatly doesn't exist in the newer API. This app now uses `modelComplexity: 1`.

Practically, this changes:
- **Library**: loaded via `<script>` tag (`@mediapipe/hands/hands.js`) in
  `index.html`, not an ES module import
- **API shape**: the older library is callback-based — you call
  `hands.send({image})` and the result arrives later via `hands.onResults()`,
  instead of the newer library's `detectForVideo()` returning a result
  immediately. `main.js` tracks an in-flight detection and won't send a new
  frame until the previous result has come back, which also naturally
  throttles the loop to whatever rate detection can actually sustain
- **Result field name**: `results.multiHandLandmarks` instead of
  `result.landmarks` — same 21-point-per-hand shape, just a different name

Everything downstream — the crop-and-zoom logic, angle smoothing, presence
hysteresis, mirror correction — is unchanged, since none of it cares which
library produced the landmarks.

One honest tradeoff: this library is in Google's "legacy" bucket (they
pointed everyone to Tasks back in 2023) so it won't get new features, but
it's stable, still hosted, and still what most real example projects use —
specifically because it has the accuracy knob the newer one lacks.

## Files

```
index.html   structure
style.css    visual design (HUD/lab theme)
main.js      MediaPipe loading, landmark drawing, direction math, bot animation
```

## Run locally

No build step. Just serve the folder (can't open index.html directly via
`file://` because ES module imports require http):

```bash
cd hand-bot
python3 -m http.server 8080
# open http://localhost:8080
```

Or use the VS Code "Live Server" extension, or `npx serve`.

## Deploy for free — GitHub + Netlify

1. **Push to GitHub**
   ```bash
   cd hand-bot
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

2. **Connect Netlify**
   - Go to [app.netlify.com](https://app.netlify.com) → "Add new site" → "Import an existing project"
   - Pick your GitHub repo
   - Build settings: leave **build command empty**, set **publish directory** to `.` (root) — there's no build step, it's static files
   - Click Deploy

3. Done. Netlify gives you a free `https://your-site.netlify.app` URL,
   auto-redeploys on every `git push`.

## How the direction math works

- Landmark **5** (index finger base / MCP joint) and landmark **8** (index
  fingertip) are read from each video frame.
- The pointing angle is `atan2(tip.y - base.y, tip.x - base.x)`, in
  on-screen degrees.
- The angle is smoothed frame-to-frame (shortest-path interpolation) so the
  bot doesn't jitter or spin the long way around.
- The bot's position is stepped forward each frame along that heading and
  clamped to stay inside the navigation panel.

## Tweaking

- `BOT_SPEED` in `main.js` — how fast the bot walks
- `numHands: 1` in `initModel()` — raise to track multiple hands
- `minHandDetectionConfidence` / `minHandPresenceConfidence` / `minTrackingConfidence`
  in `initModel()` — currently set to `0.35` (down from MediaPipe's default `0.5`)
  because the defaults were too conservative for real uploaded video and were
  missing hands that were clearly in frame. Lower = more permissive (finds the
  hand more easily, but slightly more prone to false positives). If you still
  get poor detection, try `0.25`. If you start seeing the skeleton lock onto
  things that aren't hands, raise it back toward `0.5`.
- `SMOOTH_WINDOW` in `main.js` — how many recent frames get averaged together
  for the displayed heading. Higher = steadier but slightly more laggy to
  respond to real direction changes. Lower = snappier but noisier. The
  averaging is done on unit vectors, not raw degrees, so it handles the
  -180°/180° wraparound correctly.
- `PRESENCE_ON_THRESHOLD` / `PRESENCE_OFF_THRESHOLD` in `main.js` — how many
  consecutive frames of "saw a hand" / "didn't see a hand" are required
  before the UI actually changes state. Stops single-frame flickers (in
  either direction) from causing visible jumps.
- Swap `delegate: "GPU"` to `"CPU"` in `main.js` if you see GPU/WebGL issues
  on some devices
- The bot is plain SVG inside `index.html` (`#botGroup`) — edit the shapes
  directly to restyle it

## Slow-motion playback during analysis

The video now plays back at 0.4x speed while being analyzed (you'll see
"Pause (0.4x — for accuracy)" on the button). This isn't cosmetic — it's a
real fix. Each frame now gets two detection passes (the crop-and-zoom
below), which takes real processing time. At normal 1x speed, if detection
can't keep up with the video's actual clock, frames get silently dropped —
the browser doesn't wait, it just skips whatever frame wasn't finished
analyzing in time. That looks exactly like "randomly doesn't see my hand,"
because frames are being skipped at unpredictable points depending on how
long each detection happened to take. Slowing playback down gives
detection enough headroom to actually process every single frame instead
of dropping ones it falls behind on.

If your machine is fast and detection keeps up fine at a higher speed,
`PLAYBACK_RATE` near the playback controls section in `main.js` can be
raised back toward 1.0.

## Why detection should be meaningfully better now

This is the real fix, not another threshold tweak. There's a documented,
research-confirmed weak spot in MediaPipe's hand detector: its
region-of-interest heuristic was designed assuming the hand is reasonably
close to parallel with the camera and takes up a sane portion of the frame.
When a hand is small, off-center, or at an angle relative to the camera —
which is extremely normal when someone is pointing — accuracy drops
significantly. This isn't a guess; researchers building sign-language
tools hit and documented this exact limitation.

So instead of handing MediaPipe the raw video frame and hoping, `main.js`
now does a two-pass crop-and-zoom on every frame:

1. Run detection once to get a rough fix on where the hand is
2. Crop tightly around that area, draw it onto an offscreen canvas scaled
   up to 480×480, and run detection again on **that** — a big, centered,
   well-resolved hand instead of a small one buried in a wide shot
3. Remember where the hand was, so next frame's crop can re-center on it
   without needing a full rescan every time
4. Periodically force a full-frame rescan anyway (every 20 frames), in case
   the hand moved somewhere outside the current crop

This gives the model something much closer to what it was actually trained
on. It costs a bit more compute per frame (two detection passes instead of
one, most of the time), but accuracy matters more here than speed.

If accuracy is still rough after this, the things that matter most are
the framing fundamentals: wrist/forearm visible (see above), no extreme
angles relative to the camera, decent lighting, hand not motion-blurred.

## If detection still struggles

- **Keep some wrist/forearm in frame, not just fingers.** This isn't a settings
  problem — MediaPipe's hand detector is a two-stage pipeline: a "palm
  detector" finds roughly where a hand is, then a separate model places the
  21 landmarks inside that region. The palm detector was trained mostly on
  images where a hand is attached to a visible wrist/forearm, and it's
  noticeably less reliable on tight crops of just fingers with no arm
  context. If your video frames the hand alone, try framing it with a bit of
  wrist showing — this single change tends to matter more than any
  confidence threshold.
- Make sure the hand is reasonably well-lit and not motion-blurred — fast
  hand movement in the source video is the single biggest accuracy killer
  for any frame-by-frame hand tracker, this one included.
- A plain, uncluttered background behind the hand helps a surprising amount.

## Mirroring

Uploaded videos don't all agree on which way is "left" internally — some
phone-recorded selfie-style clips store frames un-mirrored even though the
camera's live preview mirrored them while filming. There's no reliable flag
to detect this automatically, so `main.js` has one constant, `MIRROR_X`
(near the top of `drawLandmarks`), that flips x-coordinates for both the
skeleton overlay and the direction math together. It's on by default. If
you ever upload a video where the skeleton dots land correctly on the hand
but the bot still walks the wrong way (or vice versa), that's a sign this
flag needs to be flipped for that particular video source — set
`MIRROR_X = false` and reload.

## Browser support

Needs WebGL + WebAssembly (any current Chrome, Edge, Firefox, Safari).
Mobile browsers work too, though video processing is slower on weaker GPUs.
